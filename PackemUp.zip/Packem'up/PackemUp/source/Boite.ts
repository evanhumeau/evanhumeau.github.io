class Boite extends Sprite {

   //Attributs
 public type_ : number;


 //Constructeur
 public constructor (element : HTMLElement) {
   super(element);

 }

 //Méthodes

public boiteNappe() {
  this.setImage("brique.png", 100, 100);
  this.type_ = 1;
}

public boiteServiette() {
  this.setImage("monstre.png", 100, 100);
  this.type_ = 2;
}

public boiteRond() {
  this.setImage("nether.png", 100, 100);
  this.type_ = 3;
}




}