//==================================================================================================
// ANIMATION AVEC TYPESCRIPT                                                                 Jeu.ts
//==================================================================================================

// Classe  J e u //---------------------------------------------------------------------------------
class Jeu extends Scene {
 //----------------------------------------------------------------------------------------Attributs
 /* Declarer ici les attributs de la scene. */

 public boites_ : Array<Boite>
 public objet_ : Objet

public lanceur_ : number;
public compteur_ : number;
public timer_ : number;

public score_ : number;

  private zone_ : Sprite; 

 //-------------------------------------------------------------------------------------Constructeur
 public constructor(element : HTMLElement) {
  super(element,false);
  /* Ecrire ici le code qui initialise la scene. */

   this.zone_ = new Sprite(document.getElementById("zone")); //Zone est définie comme un sprite
   this.zone_.setXY(10,10); //Zone avec un margin de 10px par rapport à la page.
   this.zone_.setWidth(this.getWidth() - 20); // On retire 20 px de longueur et de hauteur 
   this.zone_.setHeight(this.getHeight() - 20);

  this.lanceur_= 5;
  this.compteur_= 40;

  this.score_= 0;
  
 }

 //--------------------------------------------------------------------------------------------start
 public override start() {
  /* Ecrire ici le code qui demarre la scene. */

  this.lancement(); //On appelle la fonction qui lance le timer 


   this.boites_ = []; //Création d'un tableau "Boites"
   let nbColonne : number = 3; 
   let nbLigne : number = 1;
   let sx : number = this.zone_.getWidth()/(nbColonne +1);
   let sy : number = this.zone_.getHeight()*0.5/(nbLigne + 1);

   for (let i = 0; i < nbLigne; i++) {
     for (let j = 0; j < nbColonne; j++) {
       let b : Boite = new Boite(document.createElement("img"));
       
       this.appendChild(b);
       b.setX((j+1)*sx-b.getWidth()/2 + this.zone_.getX());
       b.setY((i+1)*sy-b.getHeight()/2 + this.zone_.getY());
       this.boites_.push(b);

     }
     
  }
  this.placementBoites();

  // this.objet_ = new Objet(document.createElement("img"), this);
  // this.randomChoix(this.objet_);
  // this.appendChild(this.objet_);
  // this.objet_.setLimites(this.zone_);
  // this.objet_.setXY(this.getWidth()/2-this.objet_.getWidth()/2, this.getHeight()-200 );

  // this.objet_.animer();
  
 }

 //--------------------------------------------------------------------------------------------pause
 public override pause() {
  /* Ecrire ici le code qui met la scene en pause. */
  this.objet_.figer();
 }

 //------------------------------------------------------------------------------------------unpause
 public override unpause() {
  /* Ecrire ici le code qui sort la scene de la pause. */
 }

 //--------------------------------------------------------------------------------------------clean
 public override clean() {
  /* Ecrire ici le code qui nettoie la scene en vue d'un redemarrage. */
}


/*DECOMPTE AVANT LANCEMENT DE LA PARTIE*/
public lancement() {
  this.timer_ = setInterval( () => {this.prelancement(); }, 1000);  //La fonction qui lance le timer
} 

public prelancement() {
  if(this.lanceur_ <= this.timer_) { // condition qui fait que quand le timer ateint 0 le timer s'arrête
    clearInterval(this.timer_);
    this.timer();
    
    this.ajoutObjet();

  } else {
    this.lanceur_--; //Si le timer n'est pas fini, on réduit le chiffre de 1
    console.log(this.lanceur_);
    // console.log(this.timer_)
  }
  
}
/*--------------------------------------*/

/*DECOMPTE DU TEMPS RESTANT DE LA PARTIE*/
  public timer() {
      this.timer_ = setInterval( () => {this.decompte(); }, 1000);  //La fonction qui lance le timer
  } 

  public decompte() {
    if(this.compteur_ <= this.timer_) { // condition qui fait que quand le timer ateint 0 le timer s'arrête
      clearInterval(this.timer_);
      console.log("La partie est terminée");
      location.href = "#popup1";
      this.pause();
    } else {
      this.compteur_--; //Si le timer n'est pas fini, on réduit le chiffre de 1
      console.log(this.compteur_);
      // console.log(this.timer_)
    }
    
  }
/*--------------------------------------*/

/*CHOIX ENTRE TROIS SPRITES*/
   public randomChoix(objet : Objet) {
     let choix : number = Math.floor(Math.random()*3);
     if (choix == 0) { objet.nappe(); }
     else if (choix == 1) { objet.serviette(); }
     else if (choix == 2) { objet.rond(); };
   }
/*--------------------------------------*/

public ajoutObjet() {
  
  this.objet_ = new Objet(document.createElement("img"), this);
  this.randomChoix(this.objet_);
  this.appendChild(this.objet_);
  this.objet_.setLimites(this.zone_);
  this.objet_.setXY(this.getWidth()/2-this.objet_.getWidth()/2, this.getHeight()-200 );

  this.objet_.animer();
}



/*PLACEMENT DES BOITES*/
public placementBoites() {
    this.boites_[0].boiteNappe(); 
    this.boites_[1].boiteServiette(); 
    this.boites_[2].boiteRond(); 

}
/*--------------------------------------*/


/*AUGMENTER SCORE*/
public augmenterScore() {
  this.score_ = this.score_ + 1;
  console.log(this.score_)
}
/*--------------------------------------*/




}




// Fin //-------------------------------------------------------------------------------------------

//créer class carton avec comme objet choix des 3 et ajouter un typoe