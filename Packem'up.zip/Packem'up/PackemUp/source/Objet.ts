class Objet extends Anime{

 //Attributs
private ecouteurColler_ : any;
private ecouteurDecoller_ : any;
private ecouteurBouger_ : any;
 private bouge_ : any;
 private scene_ : Jeu;
 private type_ : number;


 //Constructeur
 public constructor (element : HTMLElement, scene : Jeu) {
   super(element);

   this.ecouteurBouger_ = (evt : MouseEvent) => { this.bouger(evt); };
   this.ecouteurColler_ = (evt : MouseEvent) => { this.bouge_ = true; };
   this.ecouteurDecoller_ = (evt : MouseEvent) => { this.bouge_ = false; };
   this.scene_ = scene;
 }

 //Méthodes

public nappe() {
  this.setImage("nappe.png", 100, 100);
  this.type_ = 1;
}

public serviette() {
  this.setImage("serviette.png", 100, 100);
  this.type_ = 2;
} 

public rond() {
  this.setImage("rond.png", 100, 100);
  this.type_ = 3;
}


 private bouger(evt : MouseEvent) {
  if (this.bouge_) {
    //Coordonnées de l'objet
    let nx : number = this.scene_.scaledMouseX(evt.clientX) - this.getParent().getX() - this.getWidth()/2;
    let ny : number =  this.scene_.scaledMouseY(evt.clientY) - this.getParent().getY() - this.getHeight()/2;

    //Corrections des coordoonnées
   
    if (nx >= this.xmax_) { nx = this.xmax_;}
    if (nx <= this.xmin_) { nx = this.xmin_;}

    if (ny >= this.ymax_) { ny = this.ymax_;}
    if (ny <= this.ymin_) { ny = this.ymin_;}

//    //Affecter les nouvelles coordonnées
    this.setX(nx);
    this.setY(ny);

// let rect1 = this.getRectangle();

// for (let i = this.scene_.boites_.length - 1; i >= 0; i--) {
//   if (Sprite.collision(rect1,this.scene_.boites_)) {
//     this.scene_.ajoutObjet();
//   }
//   else {
//   console.log("rip");
//   }
  
//   } 

}

let rect1 = this.getRectangle();
let coef : number = 0.3;

rect1.x_= this.getCenterX()-rect1.width_*coef;
  rect1.y_= this.getCenterY()-rect1.height_*coef;
  rect1.width_ = rect1.width_*coef;
  rect1.height_ = rect1.height_*coef;

for (let i = this.scene_.boites_.length - 1; i >= 0; i--) {
  let rect2 = this.scene_.boites_[i].getRectangle();
  rect2.x_= this.scene_.boites_[i].getCenterX()-rect2.width_*coef;
  rect2.y_= this.scene_.boites_[i].getCenterY()-rect2.height_*coef;
  rect2.width_ = rect2.width_*coef;
  rect2.height_ = rect2.height_*coef;
if (Sprite.collision(rect1,rect2) && this.type_ == this.scene_.boites_[i].type_) {
  this.scene_.augmenterScore();
  this.scene_.objet_.figer();
  this.scene_.removeChild(this.scene_.objet_);
  this.scene_.ajoutObjet();
} else if (Sprite.collision(rect1,rect2) && this.type_ != this.scene_.boites_[i].type_) {
  this.scene_.diminuerScore();
  this.scene_.objet_.figer();
  this.scene_.removeChild(this.scene_.objet_);
  this.scene_.ajoutObjet();
}

}


// this.setX(nx);
// this.setY(ny);
  }
 

 public override animer(){

  // this.addEventListener("mousedown", this.ecouteurSuivre_); //ne pas mettre l'écouteur sur window mais sur autre chose jsp quoi  
  this.addEventListener("mousedown",this.ecouteurColler_);

  this.addEventListener("mouseup",this.ecouteurDecoller_);

  window.addEventListener("mousemove",this.ecouteurBouger_);
 }

 public override figer(){
  this.removeEventListener("mousedown",this.ecouteurColler_);

  this.removeEventListener("mouseup",this.ecouteurDecoller_);

  window.removeEventListener("mousemove",this.ecouteurBouger_);
 }


  
  
}