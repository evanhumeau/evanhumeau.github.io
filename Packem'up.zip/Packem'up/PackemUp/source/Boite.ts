class Boite extends Sprite {

   //Attributs
 public type_ : number;

//  private texture_ : any;


 //Constructeur
 public constructor (element : HTMLElement) {
   super(element);

 }

 //Méthodes

public boiteNappe() {
  this.setImage("boite1.png", 100, 100);
  this.type_ = 1;
}

public boiteServiette() {
  this.setImage("boite2.png", 100, 100);
  this.type_ = 2;
}

public boiteRond() {
  this.setImage("boite3.png", 100, 100);
  this.type_ = 3;
}




}