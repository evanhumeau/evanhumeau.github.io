//==================================================================================================
// ANIMATION AVEC TYPESCRIPT                                                                 Jeu.ts
//==================================================================================================

// Classe  J e u //---------------------------------------------------------------------------------
class Jeu extends Scene {
 //----------------------------------------------------------------------------------------Attributs
 /* Declarer ici les attributs de la scene. */

 public boites_ : Array<Boite>
 public objet_ : Objet

public lanceur_ : number;
public compteur_ : number;
public timer_ : number;

 private compteurScore_ : number;
 private score1_ : Sprite; 
 private score2_ : Sprite; 
 private timer1_ : Sprite; 

 public texture_ : any;


  private zone_ : Sprite; 

 //-------------------------------------------------------------------------------------Constructeur
 public constructor(element : HTMLElement) {
  super(element,false);
  /* Ecrire ici le code qui initialise la scene. */

   this.zone_ = new Sprite(document.getElementById("zone")); //Zone est définie comme un sprite
   this.zone_.setXY(10,10); //Zone avec un margin de 10px par rapport à la page.
   this.zone_.setWidth(this.getWidth() - 20); // On retire 20 px de longueur et de hauteur 
   this.zone_.setHeight(this.getHeight() - 20);

  this.lanceur_= 5;
  this.compteur_= 40;

  this.score1_ = new Sprite(document.getElementById("scoreFinal"));
  this.score2_ = new Sprite(document.getElementById("scoreActuel"));
  this.timer1_ = new Sprite(document.getElementById("timerActuel"));
  
  this.compteurScore_ = 0;
 }

 //--------------------------------------------------------------------------------------------start
 public override start() {
  /* Ecrire ici le code qui demarre la scene. */

  // this.telechargerTexture(1);


  /* CHOSES A DECOMMENTER POUR FONCTIONNER SANS PHP */

  this.lancement(); //On appelle la fonction qui lance le timer 


   this.boites_ = []; //Création d'un tableau "Boites"
   let nbColonne : number = 3; 
   let nbLigne : number = 1;
   let sx : number = this.zone_.getWidth()/(nbColonne +1.77);
   let sy : number = this.zone_.getHeight()*1.5/(nbLigne + 1);

   for (let i = 0; i < nbLigne; i++) {
     for (let j = 0; j < nbColonne; j++) {
       let b : Boite = new Boite(document.createElement("img"));
       
       this.appendChild(b);
       b.setX((j+1)*sx-b.getWidth()/2 + this.zone_.getX());
       b.setY((i+1)*sy-b.getHeight()/2 + this.zone_.getY());
       this.boites_.push(b);

     }
     
  }
  this.placementBoites();

  // this.objet_.animer();

  this.afficherScore();
  
  /* FIN CHOSES A DECOMMENTER POUR FONCTIONNER SANS PHP */

 }

 //--------------------------------------------------------------------------------------------pause
 public override pause() {
  /* Ecrire ici le code qui met la scene en pause. */
  this.objet_.figer();
 }

 //------------------------------------------------------------------------------------------unpause
 public override unpause() {
  /* Ecrire ici le code qui sort la scene de la pause. */
 }

 //--------------------------------------------------------------------------------------------clean
 public override clean() {
  /* Ecrire ici le code qui nettoie la scene en vue d'un redemarrage. */
}


/*DECOMPTE AVANT LANCEMENT DE LA PARTIE*/
public lancement() {
  this.timer_ = setInterval( () => {this.prelancement(); }, 1000);  //La fonction qui lance le timer
} 

public prelancement() {
  if(this.lanceur_ <= this.timer_) { // condition qui fait que quand le timer ateint 0 le timer s'arrête
    clearInterval(this.timer_);
    this.timer();
    
    this.ajoutObjet();

  } else {
    this.lanceur_--; //Si le timer n'est pas fini, on réduit le chiffre de 1
    console.log(this.lanceur_);
    // console.log(this.timer_)
  }
  
}
/*--------------------------------------*/

/*DECOMPTE DU TEMPS RESTANT DE LA PARTIE*/
  public timer() {
      this.timer_ = setInterval( () => {this.decompte(); }, 1000);  //La fonction qui lance le timer
  } 

  public decompte() {
    if(this.compteur_ <= this.timer_) { // condition qui fait que quand le timer ateint 0 le timer s'arrête
      clearInterval(this.timer_);
      console.log("La partie est terminée");
      location.href = "#popup1";
      if (this.compteurScore_ <= 10) {
        this.score1_.getElement().textContent = "Votre score est de : " + this.compteurScore_ + " points";
      } else if (this.compteurScore_ >= 11 && this.compteurScore_ <= 30) {
        this.score1_.getElement().textContent = "Continuez comme ça ! Votre score est de : " + this.compteurScore_ + " points";
      } else {
        this.score1_.getElement().textContent = "Félicitation ! Votre score est de : " + this.compteurScore_ + " points";
      }
      this.pause();
    } else {
      this.compteur_--; //Si le timer n'est pas fini, on réduit le chiffre de 1
      this.timer1_.getElement().textContent = "Timeur : " + (this.compteur_-2) + "s";
      console.log(this.compteur_);
      // console.log(this.timer_)
    }
    
  }
/*--------------------------------------*/

/*CHOIX ENTRE TROIS SPRITES*/
   public randomChoix(objet : Objet) {
     let choix : number = Math.floor(Math.random()*3);
     if (choix == 0) { objet.nappe(); }
     else if (choix == 1) { objet.serviette(); }
     else if (choix == 2) { objet.rond(); };
   }
/*--------------------------------------*/

public ajoutObjet() {
  
  this.objet_ = new Objet(document.createElement("img"), this);
  this.randomChoix(this.objet_);
  this.appendChild(this.objet_);
  this.objet_.setLimites(this.zone_);
  this.objet_.setXY(this.getWidth()/2-this.objet_.getWidth()/2, this.getHeight()-320 );

  this.objet_.animer();
}



/*PLACEMENT DES BOITES*/
public placementBoites() {
    this.boites_[0].boiteNappe(); 
    this.boites_[1].boiteServiette(); 
    this.boites_[2].boiteRond(); 

}
/*--------------------------------------*/


/*AUGMENTER SCORE*/
public augmenterScore() {
  this.compteurScore_++;
  this.score2_.getElement().textContent = "Score : " + this.compteurScore_;
  console.log(this.compteurScore_)
}
/*--------------------------------------*/

/*DIMINUER SCORE*/
public diminuerScore() {
  if (this.compteurScore_ > 1) {
    this.compteurScore_--;
    this.score2_.getElement().textContent = "Score : " + this.compteurScore_;
    console.log(this.compteurScore_)
  } else {
    this.compteurScore_ = 0;
    this.score2_.getElement().textContent = "Score : " + this.compteurScore_;
  }
}
/*--------------------------------------*/


public afficherScore(){
  this.score2_.getElement().textContent = "Score : " + this.compteurScore_;
}

public initialiserNiveau(){
    this.boites_ = []; //Création d'un tableau "Boites"
   let nbColonne : number = 3; 
   let nbLigne : number = 1;
   let sx : number = this.zone_.getWidth()/(nbColonne +1.77);
   let sy : number = this.zone_.getHeight()*1.5/(nbLigne + 1);

   for (let i = 0; i < nbLigne; i++) {
     for (let j = 0; j < nbColonne; j++) {
       let b : Boite = new Boite(document.createElement("img"));
       
       this.appendChild(b);
       b.setX((j+1)*sx-b.getWidth()/2 + this.zone_.getX());
       b.setY((i+1)*sy-b.getHeight()/2 + this.zone_.getY());
       this.boites_.push(b);

     }
     
  }
}


// public telechargerTexture(idNiveau: number) {
//   /* Préparation de la requête */
//   let requete: XMLHttpRequest = new XMLHttpRequest();
//   let parametres: string = "id=" + idNiveau;
//   requete.open("get", "http://localhost/test/index.php?" + parametres);
//   /* Ecouteur déclenché à la réception des données */
//   requete.onreadystatechange = () => {
//      if (requete.readyState == XMLHttpRequest.DONE
//         && requete.status == 200) {
//         this.texture_ = JSON.parse(requete.responseText);
//         this.suiteStart();
//      }
//   };
//   requete.send(); // Envoi de la requête
// }

// public suiteStart() {
//   this.lancement(); //On appelle la fonction qui lance le timer 
//   this.placementBoites();
//   this.afficherScore();
// }

}




// Fin //-------------------------------------------------------------------------------------------

//créer class carton avec comme objet choix des 3 et ajouter un typoe